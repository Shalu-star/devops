package com.example;

import com.example.Example.PubSubMessage;
import com.google.cloud.functions.BackgroundFunction;
import com.google.cloud.functions.Context;
import java.util.Base64;
import java.util.Map;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import java.util.Properties;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Example implements BackgroundFunction<PubSubMessage> {
    private static final Logger logger = Logger.getLogger(Example.class.getName());

    @Override
    public void accept(PubSubMessage message, Context context) {
        String data = message.data != null
                ? new String(Base64.getDecoder().decode(message.data))
                : "Hello, World";
        logger.info(data);
        sendEmail(data);
    }

    public void sendEmail(String data) {

        // Recipient's email ID needs to be mentioned.
        String to = "prakash.i.s@capgemini.com,manoj-kumar.a.sharma@capgemini.com,ashish.d.kulkarni@capgemini.com,vikas.mahajan@capgemini.com";

        // Sender's email ID needs to be mentioned
        String from = "prakashsssgrd@gmail.com";

        // Assuming you are sending email from through gmails smtp
        String host = "smtp.gmail.com";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");

        // Get the Session object.// and pass username and password
        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {

            protected PasswordAuthentication getPasswordAuthentication() {

                return new PasswordAuthentication("prakashsssgrd@gmail.com", "ursbuleypopmtnlo");

            }

        });

        // Used to debug SMTP issues
        session.setDebug(true);

        try {
            // Create a default MimeMessage object.
            Message message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.

            String[] recipientList = to.split(",");
            InternetAddress[] recipientAddress = new InternetAddress[recipientList.length];
            int counter = 0;
            for (String recipient : recipientList) {
                recipientAddress[counter] = new InternetAddress(recipient.trim());
                counter++;
            }
            message.setRecipients(Message.RecipientType.TO, recipientAddress);
            //message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // Set Subject: header field
            message.setSubject(data + " :: Review Submitted!");

            // Now set the actual message
            //message.setText("New Review Added by the user... Please review it and approve." + data);
            //message.setContent("<h1>This is actual message embedded in HTML tags"+data+"</h1>", "text/html");
            message.setContent("<p>Dear Team</p><p> The Web customer has submitted review for "+ data +". <a href = \"https://mbbackoffice-nv3nzvrufa-ez.a.run.app/\">Click here</a> to review and approve the same.</p><p>Thank you!</p>", "text/html");


            logger.info("sending...");
            // Send message
            Transport.send(message);
            logger.info("Sent message successfully....");
        } catch (MessagingException mex) {
            mex.printStackTrace();
        }

    }

    public static class PubSubMessage {
        String data;
        Map<String, String> attributes;
        String messageId;
        String publishTime;
    }
}