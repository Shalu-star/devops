/**
 * Triggered from a message on a Cloud Pub/Sub topic.
 *
 * @param {!Object} event Event payload.
 * @param {!Object} context Metadata for the event.
 */
var https = require('https');
exports.helloPubSub = (event, context) => {
	const prodCode = Buffer.from(event.data, 'base64').toString()
	console.log("request: " + prodCode);
	const options = {
        method: "POST",
        host: "backoffice.caibq7rk87-capgemini2-d1-public.model-t.cc.commerce.ondemand.com",
        port: 443,
        path : "/odata2webservices/InboundProduct/Products",
        headers: {
            "Content-Type": "application/json",
			"Accept": "application/json",
            "Authorization": "Basic aW50ZWdyYXRpb25zZXJ2aWNldGVzdHVzZXI6MTIzNA=="
        }
    }
	console.log("Setting data: ");	
	const data = JSON.stringify(
		{
		  "code": prodCode,
		  "priceUpdatedString": (new Date()).toISOString(),
		  "catalogVersion": {
			"catalog": {
			  "id": "highstreetProductCatalog"
			},
			"version": "Online"
		  }
		}
	)
	console.log("Triggering Request: ");	
	const req1 = https.request(options, (res) => {
	//status code of the request sent
	console.log("statusCode: ", res.statusCode);
	let result = "";
	// A chunk of data has been recieved. Append it with the previously retrieved chunk of data
	res.on("data", (chunk) => {
		result += chunk;
	});
	//The whole response has been received. Display it into the console.
	res.on("end", () => {
		console.log("Result is: " + result);
	});
	});
	//error if any problem with the request
	req1.on("error", (err) => {
	console.log("Error: " + err.message);
	});
	//write data to request body
	req1.write(data);
	//to signify the end of the request - even if there is no data being written to the request body.
	req1.end();
	console.log("Finished execution: ");	
};

