package com.cg.dto;

public class TestDTO {
	private int test_id;
	private int studid;
	private int sub_id;
	private int qsn_id;
	private String cor_option;
	public int getTest_id() {
		return test_id;
	}
	public void setTest_id(int test_id) {
		this.test_id = test_id;
	}
	public int getStudid() {
		return studid;
	}
	public void setStudid(int studid) {
		this.studid = studid;
	}
	public int getSub_id() {
		return sub_id;
	}
	public void setSub_id(int sub_id) {
		this.sub_id = sub_id;
	}
	public int getQsn_id() {
		return qsn_id;
	}
	public void setQsn_id(int qsn_id) {
		this.qsn_id = qsn_id;
	}
	public String getCor_option() {
		return cor_option;
	}
	public void setCor_option(String cor_option) {
		this.cor_option = cor_option;
	}
	
	

}
