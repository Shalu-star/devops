package com.cg.repository;

import org.springframework.data.repository.CrudRepository;

import com.cg.entities.Subject;


public interface SubjectRepository extends CrudRepository<Subject, Integer>{

}
