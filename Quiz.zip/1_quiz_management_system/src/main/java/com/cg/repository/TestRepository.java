package com.cg.repository;
import org.springframework.data.repository.CrudRepository;
import com.cg.entities.Test;
public interface TestRepository extends CrudRepository<Test, Integer>{

}
